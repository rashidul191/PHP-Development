<?php

include_once 'config.php';



$dbConnection = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
$action = isset($_POST['action']) ?? "";
$statusCode = 0;
if (!$dbConnection) {
    throw new Exception("DataBase Connection Some Think Wrong!!");
} else {
    if ("register" == $action) {

        $email = $_POST["email"];
        $password = $_POST["password"];
        if ($email && $password) {
            $hashPassword = password_hash($password, PASSWORD_BCRYPT);
            $query = "INSERT INTO users (email, password) VALUES ('$email', '$hashPassword')";
            mysqli_query($dbConnection, $query);
            // $dbConnection->query($query);

            if (mysqli_error($dbConnection)) {
                $statusCode = 1;
            } else {
                $statusCode = 3;
            }
        } else {
            $statusCode = 2;
        }
        header("Location: index.php?status={$statusCode}");
    }
}
