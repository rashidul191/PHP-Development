<?php

function getStatusMessage($statusCode = 0)
{
    $status = array(
        "0" => "",
        "1" => "Duplicate Email !!!",
        "2" => "Username or Password Empty !!!",
        "3" => "User created successfully",
    );

    return $status[$statusCode];
}
